package com.broker.utils.strorage.support;

/**
 * @author kong <androidsimu@163.com>
 * create by 2019/3/12 9:29
 * Description: easyimbroker
 **/
public class MysqlStorage {
}
