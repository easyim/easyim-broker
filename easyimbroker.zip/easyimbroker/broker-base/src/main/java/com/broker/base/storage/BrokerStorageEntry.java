package com.broker.base.storage;

public class BrokerStorageEntry {
    public static final String MACHINE_CLIENTS = "MACHINE_CLIENTS";
    public static final String CLIENT_TO_LOGINUSER = "CLIENT_TO_LOGINUSER";
    public static final String CLIENT_USER_TOKEN = "CLIENT_USER_TOKEN";
}
